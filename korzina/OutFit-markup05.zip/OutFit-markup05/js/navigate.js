function theRotator() {		
	setInterval('rotate()',5000);
}
 
function rotate() {		
	$('.slideset li:visible:first').hide();
	if($('.slideset li:last').is(':hidden')){
		$('.slideset li').show();
	}
	
};


$(document).ready(function(){	
	theRotator();
	$('.2').hide();
	$('.3').hide();
	$('.arrow-prev').css('opacity', 0.35);
	$('.thumbs li a img').on('click', function(){
		$('.slideset li:visible:first img').attr('src', $(this).attr('src'));
			// console.log($(this).attr('src'))
			return false;
		});	
	$('.arrow-prev').on('click', function(){
		var d = $('.thumbs div:visible');
			if(!$('.thumbs div:first').is(':visible')){		
				d.prev().show();
				d.hide();
				if($('.thumbs div:first').is(':visible')){
					$('.arrow-prev').prop('disabled', true);
					$('.arrow-prev').css('opacity', 0.35);
				}else{
					$('.arrow-next').css('opacity', 1);
				}
			}	
		return false;
	});
	$('.arrow-next').on('click', function(){
		var d = $('.thumbs div:visible');
			if(!$('.thumbs div:last').is(':visible')){
				// $('.arrow-prev').css('background', 'url(../gfx/btn-prev02.png) no-repeat');
				d.next().show();
				d.hide();				
				if($('.thumbs div:last').is(':visible')){
					$('.arrow-next').prop('disabled', true);
					$('.arrow-next').css('opacity', 0.35);
				}else{
					$('.arrow-prev').css('opacity', 1);
				}
			}
		return false;
	});	

});