// page init
jQuery(function(){
	jcf.customForms.replaceAll('.c-form')
    smoothHover();
});

function hideFormText() {
	var _inputs = document.getElementsByTagName('input');
	var _txt = document.getElementsByTagName('textarea');
	var _value = [];
	
	if (_inputs) {
		for(var i=0; i<_inputs.length; i++) {
			if (_inputs[i].type == 'text' || _inputs[i].type == 'password') {
				
				_inputs[i].index = i;
				_value[i] = _inputs[i].value;
				
				_inputs[i].onfocus = function(){
					if (this.value == _value[this.index])
						this.value = '';
				}
				_inputs[i].onblur = function(){
					if (this.value == '')
						this.value = _value[this.index];
				}
			}
		}
	}
	if (_txt) {
		for(var i=0; i<_txt.length; i++) {
			_txt[i].index = i;
			_value['txt'+i] = _txt[i].value;
			
			_txt[i].onfocus = function(){
				if (this.value == _value['txt'+this.index])
					this.value = '';
			}
			_txt[i].onblur = function(){
				if (this.value == '')
					this.value = _value['txt'+this.index];
			}
		}
	}
}
if (window.addEventListener)
	window.addEventListener("load", hideFormText, false);
else if (window.attachEvent)
	window.attachEvent("onload", hideFormText);


jQuery.browser = {};
(function () {
    jQuery.browser.msie = false;
    jQuery.browser.version = 0;
    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
        jQuery.browser.msie = true;
        jQuery.browser.version = RegExp.$1;
    }
})();


function smoothHover() {
    $('.carousel3 img').each(function(){
        $(this).clone().appendTo($(this).parent()).addClass('noraml');
        $(this).grayscale().addClass('gray');
    })
}

/*

/*
 * Grayscale Image plugin
 */
;(function($){
    var filterIE = $.browser.msie && $.browser.version < 10, replaceFunc,
        filterCSS3 = !$.browser.msie && (typeof document.documentElement.style.webkitFilter !== 'undefined'),
        filterSVG = typeof document.documentElement.style.filter !== 'undefined' && $.browser.mozilla && $.browser.version >= 10;

    // grayscale image using canvas
    function grayscaleCanvas(image) {
        var canvas = document.createElement('canvas'),
            ctx = canvas.getContext('2d'),
            tmpImage = new Image();

        tmpImage.onload = function() {
            canvas.width = tmpImage.width;
            canvas.height = tmpImage.height;
            ctx.drawImage(tmpImage, 0, 0);
            var imageData = ctx.getImageData(0, 0, tmpImage.width, tmpImage.height);
            for (i = 0; i < imageData.height; i++) {
                for (j = 0; j < imageData.width; j++) {
                    var index = (i*4)*imageData.width+(j*4);
                    var red = imageData.data[index];
                    var green = imageData.data[index+1];
                    var blue = imageData.data[index+2];
                    var alpha = imageData.data[index+3];
                    var average = (red+green+blue)/3;
                    imageData.data[index] = average;
                    imageData.data[index+1] = average;
                    imageData.data[index+2] = average;
                    imageData.data[index+3] = alpha;
                }
            }
            ctx.putImageData(imageData, 0, 0, 0, 0, imageData.width, imageData.height);

            if(image.offsetWidth) {
                canvas.style.width = image.offsetWidth + 'px';
                canvas.style.height = image.offsetHeight + 'px';
            }
            image.parentNode.insertBefore(canvas, image);
            image.parentNode.removeChild(image);
        };
        tmpImage.src = image.src;
    }

    // grayscale image using css3 filter
    function grayscaleCSS3(image) {
        image.style.webkitFilter = 'grayscale(1)';
    }

    // grayscale image using svg filter
    function grayscaleSVG(image) {
        image.style.filter = 'url("data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\'><filter id=\'grayscale\'>'+
            '<feColorMatrix type=\'matrix\' values=\'0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0.3333 0.3333 0.3333 0 0 0 0 0 1 0\'/>'+
            '</filter></svg>#grayscale")';
    }

    // grayscale image using IE filter
    function grayscaleIE(image) {
        image.style.filter = 'gray';
    }

    // detect better method for current browser
    if(filterIE) {
        replaceFunc = grayscaleIE;
    } else if(filterCSS3) {
        replaceFunc = grayscaleCSS3;
    } else if(filterSVG) {
        replaceFunc = grayscaleIE;
    } else {
        replaceFunc = grayscaleCanvas;
    }

    // jQuery plugin interface
    $.fn.grayscale = function() {
        return this.each(function() {
            replaceFunc(this);
        });
    };
}(jQuery));